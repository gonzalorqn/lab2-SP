﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace SP
{
    public class Cajon<T> :ISerializar
    {
        protected int _capacidad;
        protected List<T> _elementos;
        protected double _precioUnitario;

        public List<T> Elementos
        {
            get { return this._elementos; }
        }

        public double PrecioTotal
        {
            get { return this._precioUnitario * this._elementos.Count; }
        }

        private Cajon()
        {
            this._elementos = new List<T>();
        }

        public Cajon(int capacidad) : this()
        {
            this._capacidad = capacidad;
        }

        public Cajon(double precio, int capacidad) : this(capacidad)
        {
            this._precioUnitario = precio;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Capacidad: " + this._capacidad);
            sb.AppendLine("Cantidad de elementos: " + this._elementos.Count);
            sb.AppendLine("Precio total: " + this.PrecioTotal);
            foreach (T t1 in this._elementos)
            {
                sb.AppendLine(t1.ToString());
            }
            return sb.ToString();
        }

        public static Cajon<T> operator +(Cajon<T> cajon,T fruta)
        {
            if(cajon._elementos.Count < cajon._capacidad)
            {
                cajon._elementos.Add(fruta);
            }
            return cajon;
        }

        bool ISerializar.Xml(string a)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + a;
            bool retorno;
            try
            {
                StreamWriter sw = new StreamWriter(path);
                sw.Write(this.ToString());
                sw.Close();
                retorno = true;
            }
            catch (DirectoryNotFoundException)
            {
                retorno = false;
            }
            return retorno;
        }
    }
}
