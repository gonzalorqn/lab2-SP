﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SP
{
    public class Durazno:Fruta
    {
        protected int _cantPelusa;

        public string Nombre
        {
            get { return "Durazno"; }
        }

        public override bool TieneCarozo
        {
            get { return true; }
        }

        public Durazno(string color, double peso, int pelusa) : base(color, peso)
        {
            this._cantPelusa = pelusa;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.FrutaToString());
            sb.AppendLine("Cantidad pelusa: " + this._cantPelusa);
            return sb.ToString();
        }
    }
}
