﻿using System;
using System.Text;

namespace SP
{
    public abstract class Fruta
    {
        protected string _color;
        protected double _peso;

        public abstract bool TieneCarozo
        {
            get;
        }

        public Fruta(string color,double peso)
        {
            this._color = color;
            this._peso = peso;
        }

        protected virtual string FrutaToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Color: " + this._color);
            sb.AppendLine("Peso: " + this._peso);
            if (TieneCarozo)
                sb.AppendLine("Tiene carozo: si");
            else
                sb.AppendLine("Tiene carozo: no");
            return sb.ToString();
        }
    }
}
