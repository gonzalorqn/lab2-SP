﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SP
{
    public interface IDeserializar
    {
        bool Xml(string a, out Fruta f);
    }
}
