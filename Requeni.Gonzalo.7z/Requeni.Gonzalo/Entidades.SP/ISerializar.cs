﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SP
{
    public interface ISerializar
    {
        bool Xml(string a);
    }
}
