﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace SP
{
    public class Manzana : Fruta , ISerializar , IDeserializar
    {
        protected string _provinciaOrigen;

        public string Nombre
        {
            get { return "Manzana"; }
        }

        public override bool TieneCarozo
        {
            get { return true; }
        }

        public Manzana(string color,double peso,string provincia):base(color,peso)
        {
            this._provinciaOrigen = provincia;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.FrutaToString());
            sb.AppendLine("Provincia origen: " + this._provinciaOrigen);
            return sb.ToString();
        }

        bool IDeserializar.Xml(string a, out Fruta f)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + a;
            bool retorno;
            try
            {
                string aux;
                StreamReader sr = new StreamReader(path);
                aux = sr.ReadLine();
                f = new Manzana("verde", 2, "rio negro");
                sr.Close();
                retorno = true;
            }
            catch (DirectoryNotFoundException)
            {
                retorno = false;
                f = null;
            }
            return retorno;
        }

        bool ISerializar.Xml(string a)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + a;
            bool retorno;
            try
            {
                StreamWriter sw = new StreamWriter(path);
                sw.Write(this.ToString());
                sw.Close();
                retorno = true;
            }
            catch (DirectoryNotFoundException)
            {
                retorno = false;
            }
            return retorno;
        }
    }
}
